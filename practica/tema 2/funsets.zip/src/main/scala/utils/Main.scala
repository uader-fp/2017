package utils

object Main extends App {
  import ListIntUtils._

  //val xs=List(4,4,1,10)
  
  //println(ListIntUtils.contar2(l));
  //println(contar2(filtrarPares(l)));
  //println(filtrarMultiplosDeTres(xs))
  //println(maximos(xs,2))
  //println(mediana(xs))
  println((2%10))
}
